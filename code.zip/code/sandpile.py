import numpy as np

class SandPile:

    def __init__(self, width, height, threshold=4):
        """Initialize a sandpile with the specified width and height."""
        self.width = width
        self.height = height
        self.threshold = threshold

        self.grid = np.zeros((width, height), dtype=int)

        self.mass_history = []


    def drop_sand(self, n=1, site=None):
        """Add `n` grains of sand to the grid.  Each grains of sand is added to
        a random site.

        Parameters
        ==========

        n: int

          The number of grains of sand of drop at this time step.  If left
          unspecified, defaults to 1.

        site:

          The site on which the grain(s) of sand should be dropped.  If `None`,
          a random site is used.

        """
        if site is None:
            i = np.random.randint(self.width)
            j = np.random.randint(self.height)
        else:
            i, j = site

        self.grid[i, j] += n

        if self.grid[i, j] >= self.threshold:
            stats = self.avalanche((i, j))
        else:
            stats = {
                "topples": 0,
                "area": 0,
                "loss": 0,
                "length": 0.0,
            }

        self.mass_history.append(int(self.mass()))

        return stats

    def mass(self):
        """Return the mass of the grid."""
        return np.sum(self.grid)

    def topple(self, site):
        """Topple the specified site."""
        i, j = site

        if self.grid[i, j] < self.threshold:
            return 0

        self.grid[i, j] -= self.threshold
        loss = 0

        neighbours = [
            (i - 1, j),
            (i + 1, j),
            (i, j - 1),
            (i, j + 1),
        ]

        for ni, nj in neighbours:
            if 0 <= ni < self.width and 0 <= nj < self.height:
                self.grid[ni, nj] += 1
            else:
                loss += 1

        return loss

    def avalanche(self, start):
        """Run the avalanche causing all sites to topple and store the stats of
        the avalanche in the appropriate variables.

        """
        unstable_sites = [start]
        toppled_sites = set()

        number_topples = 0
        total_loss = 0

        while unstable_sites:
            i, j = unstable_sites.pop()

            if self.grid[i, j] < self.threshold:
                continue

            total_loss += self.topple((i, j))
            number_topples += 1
            toppled_sites.add((i, j))

            if self.grid[i, j] >= self.threshold:
                unstable_sites.append((i, j))

            neighbours = [
                (i - 1, j),
                (i + 1, j),
                (i, j - 1),
                (i, j + 1),
            ]

            for ni, nj in neighbours:
                if 0 <= ni < self.width and 0 <= nj < self.height:
                    if self.grid[ni, nj] >= self.threshold:
                        unstable_sites.append((ni, nj))

        area = len(toppled_sites)

        if toppled_sites:
            length = float(max(
                np.hypot(i - start[0], j - start[1])
                for i, j in toppled_sites
            ))
        else:
            length = 0.0

        return {
            "topples": number_topples,
            "area": area,
            "loss": total_loss,
            "length": length,
        }



