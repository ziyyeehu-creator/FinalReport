# Bak--Tang--Wiesenfeld Sandpile Simulation

## Requirements

- Python 3.14
- NumPy 2.5.2
- Matplotlib 3.11.1

The required Python packages are listed in `requirements.txt`.

## Installation

From this directory, install the dependencies using:

```bash
python -m pip install -r requirements.txt
```

## Running the code

Run the complete simulation and analysis with:

```bash
python main.py
```

The program first performs validation tests. It then simulates square
lattices of sizes 3x3, 5x5, 10x10 and 20x20 using random seeds 42--46.

## Output

Numerical results and figures are generated automatically in the
`output` directory. The generated results include:

- the stationary mean-height time series;
- finite-size comparisons averaged across random seeds;
- distributions of avalanche topples, area, loss and length;
- pairwise relationships between avalanche measurements; and
- the spatial mean-height grid.

The generated `.npz` files contain the numerical data used to reproduce
the results, tables and figures in the report.