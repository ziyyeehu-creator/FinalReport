"""Run and analyse Bak--Tang--Wiesenfeld sandpile simulations.

Running this file validates the implementation, simulates four lattice
sizes using five random seeds, saves the numerical results, and creates
the figures used in the final report.
"""

from pathlib import Path

import numpy as np
from matplotlib import pyplot

from sandpile import SandPile


def run_validation_tests():
    """Validate toppling, avalanche, stability and order independence."""
    centre = SandPile(3, 3)
    centre.grid[1, 1] = 4
    assert centre.topple((1, 1)) == 0
    assert np.array_equal(
        centre.grid,
        np.array([
            [0, 1, 0],
            [1, 0, 1],
            [0, 1, 0],
        ]),
    )

    edge = SandPile(3, 3)
    edge.grid[0, 1] = 4
    assert edge.topple((0, 1)) == 1

    corner = SandPile(3, 3)
    corner.grid[0, 0] = 4
    assert corner.topple((0, 0)) == 2

    repeated = SandPile(3, 3)
    repeated.grid[1, 1] = 8
    repeated_stats = repeated.avalanche((1, 1))
    assert repeated_stats["topples"] == 2
    assert repeated_stats["area"] == 1
    assert np.all(repeated.grid < repeated.threshold)

    example = SandPile(3, 3)
    example.grid = np.array([
        [1, 3, 3],
        [2, 4, 2],
        [2, 1, 1],
    ])
    example_stats = example.avalanche((1, 1))
    assert np.array_equal(
        example.grid,
        np.array([
            [2, 1, 1],
            [3, 2, 0],
            [2, 2, 2],
        ]),
    )
    assert example_stats["topples"] == 4
    assert example_stats["area"] == 4
    assert example_stats["loss"] == 4

    initial_grid = np.array([
        [4, 0, 4],
        [0, 0, 0],
        [0, 0, 0],
    ])
    order_a = SandPile(3, 3)
    order_b = SandPile(3, 3)
    order_a.grid = initial_grid.copy()
    order_b.grid = initial_grid.copy()
    order_a.topple((0, 0))
    order_a.topple((0, 2))
    order_b.topple((0, 2))
    order_b.topple((0, 0))
    assert np.array_equal(order_a.grid, order_b.grid)

    print("Validation tests passed.")


def spatial_height_means(mean_height_grid):
    """Calculate mean heights for corners, edges and the interior.

    Parameters
    ----------
    mean_height_grid : numpy.ndarray
        Time-averaged height at every site of a square lattice.

    Returns
    -------
    tuple[float, float, float]
        Mean corner, non-corner edge and interior heights.
    """
    lattice_size = mean_height_grid.shape[0]

    boundary_mask = np.zeros_like(mean_height_grid, dtype=bool)
    boundary_mask[0, :] = True
    boundary_mask[-1, :] = True
    boundary_mask[:, 0] = True
    boundary_mask[:, -1] = True

    corner_mask = np.zeros_like(mean_height_grid, dtype=bool)
    corner_mask[0, 0] = True
    corner_mask[0, -1] = True
    corner_mask[-1, 0] = True
    corner_mask[-1, -1] = True

    edge_mask = boundary_mask & ~corner_mask
    interior_mask = ~boundary_mask

    corner_mean = float(np.mean(mean_height_grid[corner_mask]))
    edge_mean = float(np.mean(mean_height_grid[edge_mask]))
    interior_mean = (
        float(np.mean(mean_height_grid[interior_mask]))
        if lattice_size > 2
        else float("nan")
    )
    return corner_mean, edge_mean, interior_mean


def log_binned_probability(data, number_of_bins=20):
    """Calculate a log-binned probability density for positive data.

    Parameters
    ----------
    data : array-like
        Avalanche measurements to bin.
    number_of_bins : int, optional
        Number of logarithmic bins. The default is 20.

    Returns
    -------
    tuple[numpy.ndarray, numpy.ndarray]
        Geometric bin centres and probability densities. Zero and negative
        values are omitted because they cannot be displayed on log axes.
    """
    positive_data = np.asarray(data, dtype=float)
    positive_data = positive_data[positive_data > 0]
    if positive_data.size == 0:
        return np.array([]), np.array([])

    minimum = positive_data.min()
    maximum = positive_data.max()
    if minimum == maximum:
        return np.array([minimum]), np.array([1.0])

    edges = np.geomspace(minimum, maximum + 1, number_of_bins + 1)
    counts, edges = np.histogram(positive_data, bins=edges)
    widths = np.diff(edges)
    centres = np.sqrt(edges[:-1] * edges[1:])
    densities = counts / (positive_data.size * widths)
    nonempty = counts > 0
    return centres[nonempty], densities[nonempty]


def run_simulation(
    lattice_size=3,
    number_of_steps=10000,
    burn_in=100,
    seed=42,
):
    """Run one square-lattice simulation.

    Parameters
    ----------
    lattice_size : int, optional
        Side length of the square lattice.
    number_of_steps : int, optional
        Number of grains to add, one per time step.
    burn_in : int, optional
        Initial steps excluded from stationary statistics.
    seed : int, optional
        NumPy random seed used for reproducibility.

    Returns
    -------
    dict
        Time series, avalanche measurements, correlations, spatial means
        and summary statistics for the simulation.
    """
    if lattice_size < 2:
        raise ValueError("lattice_size must be at least 2")
    if not 0 <= burn_in < number_of_steps:
        raise ValueError("burn_in must satisfy 0 <= burn_in < number_of_steps")

    print(f"\n{lattice_size} x {lattice_size} sandpile simulation")
    print("Number of steps:", number_of_steps)
    print("Burn-in:", burn_in)
    print("Random seed:", seed)

    np.random.seed(seed)
    pile = SandPile(lattice_size, lattice_size)

    topples_data = []
    area_data = []
    loss_data = []
    length_data = []
    height_sum = np.zeros((lattice_size, lattice_size), dtype=float)
    total_loss_all_steps = 0

    for step in range(number_of_steps):
        statistics = pile.drop_sand()
        total_loss_all_steps += statistics["loss"]

        if step >= burn_in:
            height_sum += pile.grid
            if statistics["topples"] > 0:
                topples_data.append(statistics["topples"])
                area_data.append(statistics["area"])
                loss_data.append(statistics["loss"])
                length_data.append(statistics["length"])

    if not topples_data:
        raise RuntimeError(
            "No stationary avalanches were recorded. "
            "Increase number_of_steps or reduce burn_in."
        )

    stationary_steps = number_of_steps - burn_in
    average_height = np.asarray(pile.mass_history, dtype=float) / lattice_size**2
    stationary_height = average_height[burn_in:]
    height_blocks = np.array_split(stationary_height, 3)
    block_mean_heights = np.array([
        np.mean(block) for block in height_blocks
    ])
    mean_height_grid = height_sum / stationary_steps

    final_mass = int(pile.mass())
    if number_of_steps != final_mass + total_loss_all_steps:
        raise AssertionError("Mass conservation check failed")

    topples = np.asarray(topples_data, dtype=float)
    area = np.asarray(area_data, dtype=float)
    loss = np.asarray(loss_data, dtype=float)
    length = np.asarray(length_data, dtype=float)
    avalanche_data = np.vstack([topples, area, loss, length])
    correlation_matrix = np.corrcoef(avalanche_data)

    corner_mean, edge_mean, interior_mean = spatial_height_means(
        mean_height_grid
    )

    result = {
        "lattice_size": lattice_size,
        "number_of_steps": number_of_steps,
        "burn_in": burn_in,
        "seed": seed,
        "average_height": average_height,
        "mean_height_grid": mean_height_grid,
        "block_mean_heights": block_mean_heights,
        "topples": topples,
        "area": area,
        "loss": loss,
        "length": length,
        "correlation_matrix": correlation_matrix,
        "stationary_mean_height": float(np.mean(stationary_height)),
        "stationary_height_std": float(np.std(stationary_height)),
        "avalanche_probability": len(topples) / stationary_steps,
        "mean_loss_per_step": float(np.sum(loss) / stationary_steps),
        "total_loss_all_steps": total_loss_all_steps,
        "final_mass": final_mass,
        "corner_mean": corner_mean,
        "edge_mean": edge_mean,
        "interior_mean": interior_mean,
    }

    print("Stationary mean height:", result["stationary_mean_height"])
    print("Stationary height standard deviation:", result["stationary_height_std"])
    print("Mean heights in three stationary blocks:", block_mean_heights)
    print("Stationary avalanches recorded:", len(topples))
    print("Avalanche probability:", result["avalanche_probability"])
    print("Mean topples:", np.mean(topples))
    print("Mean area:", np.mean(area))
    print("Mean loss per avalanche:", np.mean(loss))
    print("Mean length:", np.mean(length))
    print("Mean loss per stationary step:", result["mean_loss_per_step"])
    print("Mean input per step: 1.0")
    print("Mass conservation check: passed")
    print("Mean corner height:", corner_mean)
    print("Mean non-corner edge height:", edge_mean)
    print("Mean interior height:", interior_mean)
    print("Correlation matrix:")
    print(correlation_matrix)
    return result


def plot_detailed_results(result, output_directory):
    """Create the three detailed figures used for the largest lattice.

    Parameters
    ----------
    result : dict
        Output returned by :func:`run_simulation`.
    output_directory : pathlib.Path
        Directory in which PDF figures are saved.
    """
    lattice_size = result["lattice_size"]
    number_of_steps = result["number_of_steps"]
    burn_in = result["burn_in"]
    size_label = f"{lattice_size}x{lattice_size}"
    average_height = result["average_height"]

    window = min(50, len(average_height))
    moving_average = np.convolve(
        average_height,
        np.ones(window) / window,
        mode="valid",
    )

    figure, axis = pyplot.subplots()
    axis.plot(
        average_height,
        color="lightgray",
        linewidth=0.8,
        label="Height",
    )
    axis.plot(
        np.arange(window - 1, number_of_steps),
        moving_average,
        color="black",
        linewidth=1.5,
        label=f"{window}-step moving average",
    )
    axis.axvline(burn_in, color="tab:red", linestyle="--", label="Burn-in")
    axis.set_title(f"Average Height: {lattice_size} x {lattice_size}")
    axis.set_xlabel("Number of grains added")
    axis.set_ylabel("Average height")
    axis.legend()
    figure.tight_layout()
    figure.savefig(output_directory / f"average_height_{size_label}.pdf")
    pyplot.close(figure)

    labels = ["Topples", "Area", "Loss", "Length"]
    arrays = [
        result["topples"],
        result["area"],
        result["loss"],
        result["length"],
    ]
    pairs = [
        (0, 1),
        (0, 2),
        (0, 3),
        (1, 2),
        (1, 3),
        (2, 3),
    ]

    figure, axes = pyplot.subplots(2, 3, figsize=(13, 8))
    for axis, (x_index, y_index) in zip(axes.flat, pairs):
        correlation = result["correlation_matrix"][x_index, y_index]
        axis.scatter(
            arrays[x_index],
            arrays[y_index],
            s=8,
            alpha=0.25,
        )
        axis.set_xlabel(labels[x_index])
        axis.set_ylabel(labels[y_index])
        axis.set_title(f"r = {correlation:.3f}")
    figure.suptitle(f"All Pairwise Avalanche Relationships: {size_label}")
    figure.tight_layout()
    figure.savefig(
        output_directory / f"pairwise_relationships_{size_label}.pdf"
    )
    pyplot.close(figure)

    figure, axis = pyplot.subplots()
    image = axis.imshow(
        result["mean_height_grid"],
        cmap="viridis",
        vmin=0,
        vmax=3,
    )
    tick_step = max(1, lattice_size // 10)
    ticks = np.arange(0, lattice_size, tick_step)
    axis.set_xticks(ticks)
    axis.set_yticks(ticks)
    axis.set_xlabel("Column")
    axis.set_ylabel("Row")
    axis.set_title(f"Mean Height at Each Site: {size_label}")
    figure.colorbar(image, ax=axis, label="Mean height")
    figure.tight_layout()
    figure.savefig(output_directory / f"mean_height_grid_{size_label}.pdf")
    pyplot.close(figure)


def save_result(result, output_directory):
    """Save one simulation result as a reproducible NumPy ``.npz`` file."""
    size_label = f"{result['lattice_size']}x{result['lattice_size']}"
    results_file = (
        output_directory
        / f"sandpile_{size_label}_seed_{result['seed']}.npz"
    )
    np.savez(results_file, **result)
    print("Numerical results saved to:", results_file)


def plot_avalanche_distributions_by_size(results, output_directory):
    """Plot four avalanche distributions for all lattice sizes.

    Parameters
    ----------
    results : list[dict]
        Seed-42 results returned by :func:`run_simulation`.
    output_directory : pathlib.Path
        Directory in which the PDF figure is saved.
    """
    keys_and_titles = [
        ("topples", "Topples"),
        ("area", "Area"),
        ("loss", "Loss"),
        ("length", "Length"),
    ]
    figure, axes = pyplot.subplots(2, 2, figsize=(10, 8))
    for axis, (key, title) in zip(axes.flat, keys_and_titles):
        for result in results:
            values, probabilities = log_binned_probability(result[key])
            axis.plot(
                values,
                probabilities,
                marker="o",
                markersize=3,
                linewidth=1,
                label=f"L={result['lattice_size']}",
            )
        axis.set_xscale("log")
        axis.set_yscale("log")
        axis.set_xlabel(title)
        axis.set_ylabel("Probability density")
        axis.set_title(title)
        axis.legend()
        axis.grid(alpha=0.25)
    figure.suptitle("Avalanche Distributions for Different Lattice Sizes")
    figure.tight_layout()
    figure.savefig(output_directory / "avalanche_distributions_by_size.pdf")
    pyplot.close(figure)


def summarise_multiple_seeds(all_results, output_directory):
    """Save and plot means and sample standard deviations across seeds.

    Parameters
    ----------
    all_results : dict[int, list[dict]]
        Simulation results grouped by lattice size.
    output_directory : pathlib.Path
        Directory in which summary data and the PDF figure are saved.
    """
    metric_functions = {
        "height": lambda result: result["stationary_mean_height"],
        "avalanche_probability": lambda result: result["avalanche_probability"],
        "topples": lambda result: np.mean(result["topples"]),
        "area": lambda result: np.mean(result["area"]),
        "loss": lambda result: np.mean(result["loss"]),
        "length": lambda result: np.mean(result["length"]),
        "loss_per_step": lambda result: result["mean_loss_per_step"],
    }
    lattice_sizes = np.array(sorted(all_results))
    summary = {
        "lattice_sizes": lattice_sizes,
        "seeds": np.array([
            result["seed"] for result in all_results[lattice_sizes[0]]
        ]),
    }

    print("\nResults averaged across random seeds")
    for metric_name, metric_function in metric_functions.items():
        means = []
        standard_deviations = []
        for lattice_size in lattice_sizes:
            values = np.array([
                metric_function(result)
                for result in all_results[lattice_size]
            ])
            means.append(np.mean(values))
            standard_deviations.append(np.std(values, ddof=1))

        summary[f"{metric_name}_mean"] = np.array(means)
        summary[f"{metric_name}_std"] = np.array(standard_deviations)
        print(f"\n{metric_name}:")
        for lattice_size, mean, standard_deviation in zip(
            lattice_sizes,
            means,
            standard_deviations,
        ):
            print(
                f"  L={lattice_size}: "
                f"{mean:.6f} +/- {standard_deviation:.6f}"
            )

    summary_file = output_directory / "multiple_seed_summary.npz"
    np.savez(summary_file, **summary)
    print("\nMultiple-seed summary saved to:", summary_file)

    figure, axes = pyplot.subplots(2, 2, figsize=(10, 8))
    panels = [
        ("height", "Stationary mean height"),
        ("avalanche_probability", "Avalanche probability"),
        ("loss_per_step", "Mean loss per step"),
    ]
    for axis, (key, label) in zip(axes.flat[:3], panels):
        axis.errorbar(
            lattice_sizes,
            summary[f"{key}_mean"],
            yerr=summary[f"{key}_std"],
            marker="o",
            capsize=4,
        )
        axis.set_ylabel(label)

    for key, label in [
        ("topples", "Topples"),
        ("area", "Area"),
        ("loss", "Loss"),
        ("length", "Length"),
    ]:
        axes[1, 1].errorbar(
            lattice_sizes,
            summary[f"{key}_mean"],
            yerr=summary[f"{key}_std"],
            marker="o",
            capsize=4,
            label=label,
        )
    axes[1, 1].set_ylabel("Mean per avalanche")
    axes[1, 1].legend()

    for axis in axes.flat:
        axis.set_xlabel("Lattice side length L")
        axis.grid(alpha=0.25)
    figure.suptitle("Finite-Size Results Averaged Across Random Seeds")
    figure.tight_layout()
    figure.savefig(output_directory / "multiple_seed_size_comparison.pdf")
    pyplot.close(figure)


def main():
    """Run validation, simulations, data export and report plotting."""
    run_validation_tests()

    output_directory = Path(__file__).resolve().parent / "output"
    output_directory.mkdir(exist_ok=True)

    configurations = [
        # lattice size, number of steps, burn-in
        (3, 10000, 100),
        (5, 20000, 500),
        (10, 50000, 2000),
        (20, 100000, 10000),
    ]
    seeds = [42, 43, 44, 45, 46]

    seed_42_results = []
    all_results = {}

    for lattice_size, number_of_steps, burn_in in configurations:
        seed_results = []
        for seed in seeds:
            result = run_simulation(
                lattice_size=lattice_size,
                number_of_steps=number_of_steps,
                burn_in=burn_in,
                seed=seed,
            )
            save_result(result, output_directory)
            seed_results.append(result)

            if seed == 42:
                seed_42_results.append(result)
                if lattice_size == 20:
                    plot_detailed_results(result, output_directory)

        all_results[lattice_size] = seed_results

    plot_avalanche_distributions_by_size(
        seed_42_results,
        output_directory,
    )
    summarise_multiple_seeds(
        all_results,
        output_directory,
    )
    print("\nAll simulations and plots completed.")


if __name__ == "__main__":
    main()
